# Módulo Sensores Marte

Descripción y lógica correspondiente al módulo.