# Módulo Hechizos Mundo Magico

Descripción y lógica correspondiente al módulo.