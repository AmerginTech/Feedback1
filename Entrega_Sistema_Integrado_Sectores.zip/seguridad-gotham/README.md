# Módulo Seguridad Gotham

Descripción y lógica correspondiente al módulo.